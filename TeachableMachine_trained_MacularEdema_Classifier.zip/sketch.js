// This code snippet has been partially taken from coding train's teachable machine image classifier code
// APIs for uploading image has been added to allow user input
// The model url used here comes from Teachable machine's trained model in Tensorflow.js

let img;
// For displaying the label
let label = "waiting for input"
let res = "Please upload retinal image to grade";
let confidence = ""
// The classifier
let classifier;
let modelURL = 'https://teachablemachine.withgoogle.com/models/uzWLnsJ_i/';

// STEP 1: Load the model!
function preload() {
  classifier = ml5.imageClassifier(modelURL + 'model.json');
  
}


function setup() {
  createCanvas(640, 520);
  input = createFileInput(handleFile);   

  // STEP 2: Start classifying
  //classifyVideo();
}

// STEP 2 classify the image!
function classifyImage() {
  classifier.classify(img, gotResults);
}

function draw() {
  background(0);
if (img) {
    image(img, 0, 0, width, height);
  }
  // STEP 4: Draw the label
  textSize(32);
  textAlign(CENTER, CENTER);
  fill(255);
  
  text(confidence, width / 2, height - 16);
  
  let emoji = "👁";  
  if (label == "Class 1") {
    res = "Grade 0"
  } else if (label == "Class 2") {
    res = "Grade 1";
  
  }
  textSize(32);
  textAlign(CENTER, CENTER);
  fill(255);
  text(res, width/2, height - 50)
  text(emoji, width/2, height - 100)
  // Draw the emoji
  //textSize(256);
  //image(img, width / 4, height/ 5, width / 2, height / 2);    
}

// STEP 3: Get the classification!
function gotResults(error, results) {
  // Something went wrong!
  if (error) {
    console.error(error);
    return;
  }
  // Store the label and classify again!
  label = results[0].label;
  confidence = results[0].confidence * 100;
  confidence = "Confidence of grade : " + round(confidence) + " %";
  
}


function handleFile(file) { 
  print(file); 
  if (file.type === 'image') { 
    img = createImg(file.data); 
    img.hide();
    confidence = "Calculating confidence score.."
    res = "Predicting grade.."
    classifyImage();
  } 
}
